<?php 
$navigation = array (
    [
        "name"=>"Domov","refference"=>"index.php"
    ],
    [
        "name" => "Opravila", 
        "refference" => "to-do.php"
    ],
    [
        "name" => "O meni", 
        "refference" => "o-meni.php"
    ],
    [
        "name" => "Kontakt",
        "refference" => "kontakt.php"
    ],
    [
        "name" => "Nastavitve",
        "refference" => "nastavitve.php"
    ]
);